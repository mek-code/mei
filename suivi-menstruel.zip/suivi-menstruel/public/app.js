(() => {
const C = window.Calc, $ = (s, e = document) => e.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const MOIS = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
const S = { user: null, cycles: [], profile: {}, journal: [], month: null };
const today = () => { const t = new Date(); return new Date(t - t.getTimezoneOffset() * 6e4).toISOString().slice(0, 10); };
const fr = s => { const [y, m, d] = s.split('-').map(Number); return `${d} ${MOIS[m - 1]} ${y}`; };
const analysis = () => C.analyze(S.cycles, S.profile, today());

async function api(p, method = 'GET', body) {
  const r = await fetch('/api' + p, { method, credentials: 'same-origin', headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
  let j = {}; try { j = await r.json(); } catch (e) {}
  if (!r.ok) throw Object.assign(new Error(j.error || 'Une erreur est survenue.'), { status: r.status });
  return j;
}
async function refresh() {
  const [a, b, c] = await Promise.all([api('/cycles'), api('/profile'), api('/journal')]);
  S.cycles = a.cycles; S.profile = b.profile; S.journal = c.journal;
}
function bind(sel, fn, root = document) {
  root.querySelectorAll(sel).forEach(f => f.addEventListener('submit', async e => {
    e.preventDefault();
    const m = $('.msg', f), set = (t, ok) => { if (m) { m.textContent = t; m.className = 'msg ' + (ok ? 'ok' : 'err'); } };
    try { await fn(Object.fromEntries(new FormData(f)), set, f); } catch (x) { set(x.message, false); }
  }));
}

const DISC = `<aside class="note" role="note"><strong>Important :</strong> les dates affichées sont des estimations. Aucun jour n’est « sans risque » : un calendrier ne permet pas d’éviter une grossesse de façon fiable. Ce site est informatif et ne remplace pas un professionnel de santé.</aside>`;
const LABELS = {
  period: ['●', 'Règles enregistrées'], traces: ['·', 'Simples traces enregistrées'], next: ['○', 'Prochaines règles estimées'],
  fertile: ['▲', 'Fertilité potentiellement plus élevée (estimation)'], ovu: ['★', 'Ovulation estimée, incertaine : fertilité potentiellement plus élevée'],
  lower: ['▽', 'Probabilité potentiellement plus faible selon les estimations (jamais « sans risque »)'], uncertain: ['?', 'Période incertaine : estimation insuffisante']
};
const PUB = [['', 'Accueil'], ['a-propos', 'Fonctionnement'], ['conseils', 'Conseils']];
const PRIV = [['tableau', 'Tableau de bord'], ['calendrier', 'Calendrier'], ['profil', 'Profil menstruel'], ['historique', 'Historique'], ['rapport', 'Après un rapport'], ['parametres', 'Paramètres']];
const PRIVSET = new Set(PRIV.map(x => x[0]));

const addForm = () => `<form id="addf" class="row"><label>Premier jour des règles<input type="date" name="start" required max="${today()}" value="${today()}"></label><label>Dernier jour (facultatif)<input type="date" name="end"></label><label class="chk"><input type="checkbox" name="traces"> Simples traces seulement</label><button class="btn">Enregistrer</button><p class="msg" role="status"></p></form>`;
const bindAdd = () => bind('#addf', async f => { await api('/cycles', 'POST', { start: f.start, end: f.end || null, traces: f.traces ? 1 : 0 }); await refresh(); route(); });

const V = {};
V[''] = () => `<section class="hero"><h1>Comprendre votre cycle, à votre rythme</h1><p>Notez vos règles, visualisez des estimations pour les semaines à venir et trouvez des informations claires, y compris si vos cycles sont irréguliers.</p><p><a class="btn" href="#/inscription">Créer mon compte</a> <a class="btn alt" href="#/a-propos">Comment ça marche</a></p></section>${DISC}
<div class="grid3"><article class="card"><h2>Suivre vos règles</h2><p>Enregistrez vos dates, corrigez-les à tout moment et gardez l’historique de vos cycles.</p></article><article class="card"><h2>Voir les estimations</h2><p>Prochaines règles, phases du cycle et fenêtre fertile estimée, avec un niveau d’incertitude toujours affiché.</p></article><article class="card"><h2>Agir après un rapport non protégé</h2><p>Délais de la contraception d’urgence et du test de grossesse, et quand demander conseil.</p></article></div>`;

V['a-propos'] = () => `<h1>Comment fonctionnent les estimations</h1>${DISC}
<section class="card"><h2>Ce que fait le calcul</h2><p>Le site ne suppose jamais que votre cycle dure 28 jours. Il utilise la durée de vos derniers cycles (six au maximum) ou, à défaut, la durée habituelle que vous indiquez. Les champs que vous ne connaissez pas peuvent rester vides.</p><p>Les prochaines règles sont estimées à partir de la date de vos dernières règles. L’ovulation est estimée environ 14 jours avant les règles suivantes ; la fenêtre fertile est élargie lorsque vos cycles varient.</p></section>
<section class="card"><h2>Le niveau d’incertitude</h2><p><strong>Faible</strong> : au moins trois cycles réguliers. <strong>Modérée</strong> : peu de cycles ou cycles un peu variables. <strong>Élevée</strong> : historique insuffisant ou cycles très variables ; la fenêtre fertile n’est alors pas affichée.</p></section>
<section class="card"><h2>Les limites</h2><p>Un calendrier ne peut pas déterminer avec certitude le jour de l’ovulation ni garantir qu’un rapport non protégé n’entraînera pas de grossesse. Stress, maladie, post-partum, adolescence ou préménopause peuvent décaler l’ovulation. En cas de doute, demandez conseil à un professionnel de santé.</p></section>`;

V.conseils = () => `<h1>Conseils et ressources</h1><p>Informations générales à faire valider par un professionnel de santé avant mise en ligne.</p>
<section class="card"><h2>Contraception</h2><p>Il existe plusieurs méthodes : préservatif (le seul à protéger aussi des infections sexuellement transmissibles), pilule, implant, dispositif intra-utérin (stérilet), injection, méthodes de barrière. Le choix dépend de votre santé, de vos préférences et de ce qui est disponible près de chez vous : un professionnel de santé peut vous aider à choisir.</p></section>
<section class="card"><h2>Santé menstruelle</h2><p>Un cycle normal varie d’une personne à l’autre et d’un mois à l’autre. Consultez si vos règles sont très abondantes, très douloureuses, si elles disparaissent plusieurs mois sans grossesse, ou si vos cycles changent nettement.</p></section>
<section class="card"><h2>Contraception d’urgence</h2><p>Elle est généralement plus efficace lorsqu’elle est utilisée rapidement. Selon la méthode, elle est possible jusqu’à 3 jours ou jusqu’à 5 jours après le rapport. Voir la page « Après un rapport » une fois connectée.</p></section>`;

V.confidentialite = () => `<h1>Confidentialité et conditions d’utilisation</h1><p>Modèle à compléter et faire valider juridiquement avant mise en production.</p>
<section class="card"><h2>Données collectées</h2><p>Adresse e-mail, mot de passe (stocké sous forme hachée), dates de règles, informations de profil menstruel, notes de journal et dates saisies dans l’outil « après un rapport ». Ce sont des données de santé sensibles : elles ne sont ni vendues, ni utilisées à d’autres fins.</p></section>
<section class="card"><h2>Vos droits</h2><p>Vous pouvez corriger vos données, désactiver les rappels et supprimer votre compte et toutes vos données depuis « Paramètres ». La suppression est immédiate et définitive. Responsable du traitement : <em>[à compléter]</em>. Durée de conservation : jusqu’à suppression du compte <em>[à confirmer]</em>.</p></section>
<section class="card"><h2>Conditions d’utilisation</h2><p>Le service fournit des informations éducatives et des estimations, sans garantie. Il ne remplace ni un avis médical ni une méthode contraceptive. L’utilisatrice est responsable de la confidentialité de son mot de passe.</p></section>`;

V.connexion = () => [`<h1>Connexion</h1><form id="lf" class="card"><label>Adresse e-mail<input type="email" name="email" required autocomplete="username"></label><label>Mot de passe<input type="password" name="password" required autocomplete="current-password"></label><button class="btn">Se connecter</button><p class="msg" role="status"></p><p><a href="#/mot-de-passe-oublie">Mot de passe oublié ?</a> · <a href="#/inscription">Créer un compte</a></p></form>`,
  () => bind('#lf', async f => { await api('/login', 'POST', f); await start(); location.hash = '#/tableau'; })];
V.inscription = () => [`<h1>Créer mon compte</h1><form id="rf" class="card"><label>Adresse e-mail<input type="email" name="email" required autocomplete="username"></label><label>Mot de passe (10 caractères minimum)<input type="password" name="password" required minlength="10" autocomplete="new-password"></label><label class="chk"><input type="checkbox" name="consent" required> J’accepte les <a href="#/confidentialite">conditions d’utilisation</a> et je comprends que mes données de santé sont enregistrées pour fournir le service.</label><button class="btn">Créer mon compte</button><p class="msg" role="status"></p></form>`,
  () => bind('#rf', async f => { await api('/register', 'POST', { email: f.email, password: f.password, consent: !!f.consent }); await start(); location.hash = '#/profil'; })];
V['mot-de-passe-oublie'] = () => [`<h1>Mot de passe oublié</h1><form id="pf" class="card"><label>Adresse e-mail<input type="email" name="email" required></label><button class="btn">Recevoir un lien</button><p class="msg" role="status"></p></form>`,
  () => bind('#pf', async (f, set) => { await api('/reset-request', 'POST', f); set('Si un compte existe avec cette adresse, un lien vient d’être envoyé.', true); })];
V.reinitialiser = q => [`<h1>Nouveau mot de passe</h1><form id="nf" class="card"><label>Nouveau mot de passe (10 caractères minimum)<input type="password" name="password" required minlength="10" autocomplete="new-password"></label><button class="btn">Enregistrer</button><p class="msg" role="status"></p></form>`,
  () => bind('#nf', async (f, set) => { await api('/reset', 'POST', { token: q.get('token') || '', password: f.password }); set('Mot de passe modifié. Vous pouvez vous connecter.', true); setTimeout(() => location.hash = '#/connexion', 1500); })];

const LV = { low: ['faible', 'Au moins trois cycles réguliers sont enregistrés.'], moderate: ['modérée', 'Les données sont limitées ou un peu variables : prenez les dates avec une marge.'], high: ['élevée', 'L’historique est limité ou vos cycles varient beaucoup : les estimations sont peu précises.'] };
function phase(a) {
  const t = today(), s = a.state(t);
  if (s === 'period') return 'Règles (enregistrées)';
  if (!a.sufficient) return 'Phase non estimable : données insuffisantes ou cycles trop variables';
  if (a.late > 0) return 'Cycle plus long que l’estimation';
  if (s === 'ovu' || s === 'fertile') return 'Fenêtre fertile estimée';
  return t < a.wins[0].from ? 'Avant la fenêtre fertile estimée (phase folliculaire)' : 'Après la fenêtre fertile estimée (phase lutéale)';
}
V.tableau = () => {
  const a = analysis();
  let h = '<h1>Tableau de bord</h1>';
  if (S.profile.reminders && a.nextStart && C.diff(a.nextStart, today()) <= 2) h += `<aside class="note" role="status">Rappel : pensez à noter vos règles si elles ont commencé.</aside>`;
  if (a.level === 'none') {
    h += `<section class="card"><h2>Pour commencer</h2><p>${a.reason === 'no-length' ? 'Une seule date est enregistrée. Ajoutez un autre début de règles ou la durée habituelle de votre cycle (Profil menstruel) pour obtenir une estimation.' : 'Indiquez le premier jour de vos dernières règles. Le reste est facultatif.'}</p>${addForm()}</section>${DISC}`;
    return [h, bindAdd];
  }
  const [lv, lvTxt] = LV[a.level];
  const w = a.wins.find(x => x.to >= today()) || a.wins[0];
  h += `<div class="grid2"><section class="card"><h2>Prochaines règles estimées</h2><p class="big">vers le ${fr(a.nextStart)}</p>${a.pad ? `<p>À plus ou moins ${a.pad} jour(s).</p>` : ''}${a.late > 0 ? `<p>L’estimation a ${a.late} jour(s) de retard. Si vos règles sont arrivées, enregistrez-les ci-dessous.</p>` : ''}<details><summary>Comment est-ce calculé ?</summary><p>Date de vos dernières règles (${fr(a.lastStart)}) + durée moyenne de cycle de ${a.avg} jours${a.n ? ` (calculée sur ${a.n} cycle(s))` : ' (durée que vous avez indiquée)'}.</p></details></section>
<section class="card"><h2>Niveau d’incertitude</h2><p class="big"><span class="badge">${lv}</span></p><p>${lvTxt}</p></section>
<section class="card"><h2>Phase d’aujourd’hui</h2><p class="big">${phase(a)}</p><details><summary>Pourquoi ?</summary><p>Jour ${C.diff(today(), a.lastStart) + 1} du cycle en cours. Les phases ne sont affichées que si les données sont suffisantes.</p></details></section>
<section class="card"><h2>Fenêtre fertile estimée</h2>${a.sufficient ? `<p class="big">du ${fr(w.from)} au ${fr(w.to)}</p><p>Ovulation estimée vers le ${fr(w.ovu)}. C’est une estimation : la fertilité est potentiellement plus élevée à cette période, mais une grossesse reste possible à d’autres moments.</p>` : `<p>Estimation insuffisante : l’historique est trop court ou trop variable pour afficher une fenêtre fertile fiable.</p>`}</section></div>
<section class="card"><h2>Mes règles ont commencé</h2>${addForm()}</section>${DISC}`;
  return [h, bindAdd];
};

function drawCal(root) {
  const { y, m } = S.month, a = analysis(), off = (new Date(Date.UTC(y, m, 1)).getUTCDay() + 6) % 7, n = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
  $('#mt').textContent = `${MOIS[m]} ${y}`;
  let h = `<table class="cal"><caption class="sr">${MOIS[m]} ${y}</caption><thead><tr>${['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'].map(d => `<th scope="col">${d}</th>`).join('')}</tr></thead><tbody><tr>`;
  for (let i = 0; i < off; i++) h += '<td></td>';
  for (let d = 1; d <= n; d++) {
    const ds = `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`, st = a.state(ds), [sym, lab] = LABELS[st] || ['', 'Aucune information'];
    h += `<td><button type="button" class="day st-${st}${ds === today() ? ' today' : ''}" data-day="${ds}" aria-label="${fr(ds)}${ds === today() ? ' (aujourd’hui)' : ''} : ${esc(lab)}"><span>${d}</span><i aria-hidden="true">${sym}</i></button></td>`;
    if ((off + d) % 7 === 0 && d < n) h += '</tr><tr>';
  }
  $('#cal').innerHTML = h + '</tr></tbody></table>';
  root.querySelectorAll('.day').forEach(b => b.addEventListener('click', () => {
    const ds = b.dataset.day, [, lab] = LABELS[a.state(ds)] || ['', 'Aucune information pour ce jour.'];
    $('#dayinfo').innerHTML = `<h2>${fr(ds)}</h2><p>${esc(lab)}</p><p>Estimation : ne constitue jamais une garantie.</p>${ds <= today() ? `<button class="btn" id="mark">Mes règles ont commencé ce jour</button><p class="msg" role="status"></p>` : ''}`;
    const mk = $('#mark'); if (mk) mk.addEventListener('click', async () => { try { await api('/cycles', 'POST', { start: ds, traces: 0 }); await refresh(); drawCal(root); } catch (e) { $('#dayinfo .msg').textContent = e.message; } });
  }));
}
V.calendrier = () => {
  if (!S.month) { const t = today(); S.month = { y: +t.slice(0, 4), m: +t.slice(5, 7) - 1 }; }
  return [`<h1>Mon calendrier</h1><div class="calnav"><button class="btn alt" id="pv" aria-label="Mois précédent">←</button><h2 id="mt" aria-live="polite"></h2><button class="btn alt" id="nx" aria-label="Mois suivant">→</button></div><div id="cal"></div><div id="dayinfo" class="card" aria-live="polite"><p>Sélectionnez un jour pour voir son explication.</p></div><h2>Légende</h2><ul class="legend">${Object.values(LABELS).map(([s, l]) => `<li><span aria-hidden="true">${s}</span> ${l}</li>`).join('')}</ul>${DISC}`,
    () => {
      const root = $('#app'), go = k => { S.month.m += k; if (S.month.m < 0) { S.month.m = 11; S.month.y--; } if (S.month.m > 11) { S.month.m = 0; S.month.y++; } drawCal(root); };
      $('#pv').onclick = () => go(-1); $('#nx').onclick = () => go(1); drawCal(root);
    }];
};

V.profil = () => {
  const p = S.profile, v = k => p[k] ?? '';
  return [`<h1>Mon profil menstruel</h1><p>Tous les champs sont facultatifs : laissez vide ce que vous ne connaissez pas.</p><form id="pf" class="card"><label>Durée habituelle des règles (jours)<input type="number" name="period_len" min="1" max="15" value="${v('period_len')}"></label><label>Durée habituelle du cycle (jours)<input type="number" name="cycle_len" min="15" max="90" value="${v('cycle_len')}"></label><label>Écart habituel entre vos cycles (jours, par exemple 3 si vos cycles varient de 3 jours)<input type="number" name="cycle_var" min="0" max="30" value="${v('cycle_var')}"></label><button class="btn">Enregistrer</button><p class="msg" role="status"></p></form>${DISC}`,
    () => bind('#pf', async (f, set) => { await api('/profile', 'PUT', { ...f, reminders: S.profile.reminders }); await refresh(); set('Profil enregistré. Les estimations sont mises à jour.', true); })];
};

V.historique = () => {
  const rows = [...S.cycles].reverse().map(c => `<form class="row card" data-id="${c.id}"><label>Début<input type="date" name="start" required value="${c.start}" max="${today()}"></label><label>Fin<input type="date" name="end" value="${c.end || ''}"></label><label class="chk"><input type="checkbox" name="traces"${c.traces ? ' checked' : ''}> Simples traces</label><button class="btn">Modifier</button><button class="btn del" type="button" data-del="${c.id}">Supprimer</button><p class="msg" role="status"></p></form>`).join('') || '<p>Aucun cycle enregistré.</p>';
  const notes = S.journal.filter(j => j.kind === 'note').map(j => `<li>${fr(j.day)} — ${esc(j.data.type)} : ${esc(j.data.text)} <button class="btn del" type="button" data-jdel="${j.id}">Supprimer</button></li>`).join('') || '<li>Aucune note.</li>';
  return [`<h1>Mon historique</h1><section class="card"><h2>Ajouter des règles</h2>${addForm()}</section><h2>Mes cycles</h2>${rows}<h2>Journal (facultatif)</h2><form id="jf" class="card row"><label>Date<input type="date" name="day" required max="${today()}" value="${today()}"></label><label>Type<select name="type"><option>Symptôme</option><option>Douleur</option><option>Saignement</option><option>Observation</option></select></label><label>Note<input name="text" required maxlength="300"></label><button class="btn">Ajouter</button><p class="msg" role="status"></p></form><ul>${notes}</ul>`,
    () => {
      bindAdd();
      bind('form[data-id]', async (f, set, el) => { await api('/cycles/' + el.dataset.id, 'PUT', { start: f.start, end: f.end || null, traces: f.traces ? 1 : 0 }); await refresh(); route(); });
      document.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => { if (confirm('Supprimer ce cycle ?')) { await api('/cycles/' + b.dataset.del, 'DELETE'); await refresh(); route(); } });
      document.querySelectorAll('[data-jdel]').forEach(b => b.onclick = async () => { await api('/journal/' + b.dataset.jdel, 'DELETE'); await refresh(); route(); });
      bind('#jf', async f => { await api('/journal', 'POST', { kind: 'note', day: f.day, data: { type: f.type, text: f.text } }); await refresh(); route(); });
    }];
};

const CONTRA = { aucune: 'aucune contraception', preservatif: 'préservatif', pilule: 'pilule ou méthode hormonale', autre: 'autre ou inconnue' };
const INC = { aucun: 'aucun incident connu', dechire: 'préservatif déchiré ou glissé', oubli: 'oubli ou retard de contraceptif', autre: 'autre ou inconnu' };
function advice(f) {
  const a = analysis(), k = C.diff(today(), f.day), risk = f.contra !== 'preservatif' && f.contra !== 'pilule' || f.inc !== 'aucun';
  return `<section class="card"><h2>Informations générales</h2><p>${risk ? 'Dans cette situation, un risque de grossesse ne peut pas être exclu.' : 'Aucune méthode n’est efficace à 100 % : un risque résiduel existe.'} Ce site ne calcule pas de probabilité individuelle et ne pose aucun diagnostic. Situation indiquée : ${CONTRA[f.contra]} ; ${INC[f.inc]}.</p>
<h3>Contraception d’urgence</h3>${k <= 5 ? `<p><strong>Le rapport date d’il y a ${k} jour(s) : n’attendez pas.</strong> La contraception d’urgence est généralement plus efficace lorsqu’elle est utilisée rapidement. Selon la méthode et votre situation, certaines options sont possibles jusqu’à 3 jours, d’autres jusqu’à 5 jours. Un pharmacien ou un professionnel de santé peut vous indiquer l’option adaptée.</p>` : `<p>Le rapport date de plus de 5 jours : la plupart des options de contraception d’urgence ne sont plus indiquées. Consultez rapidement un professionnel de santé pour connaître vos possibilités.</p>`}
<h3>Test de grossesse</h3><p>Un test peut être fait dès le retard des règles. Si la date attendue est inconnue, faites-le au moins 21 jours après le dernier rapport non protégé, soit à partir du <strong>${fr(C.add(f.day, 21))}</strong>.${a.nextStart ? ` Vos prochaines règles sont estimées vers le ${fr(a.nextStart)} (estimation).` : ''}</p>
<h3>Quand demander conseil</h3><p>Demandez conseil à un pharmacien, une sage-femme, un médecin ou un centre de santé : pour choisir la contraception d’urgence, après un test positif, en cas de douleurs ou de saignements inhabituels, ou pour un dépistage des infections sexuellement transmissibles. Si le rapport n’était pas consenti, un professionnel de santé peut vous accompagner.</p></section>`;
}
V.rapport = () => {
  const reps = S.journal.filter(j => j.kind === 'rapport').map(j => `<li>${fr(j.day)} — ${CONTRA[j.data.contra] || ''} ; ${INC[j.data.inc] || ''} <button class="btn del" type="button" data-jdel="${j.id}">Supprimer</button></li>`).join('') || '<li>Aucun rapport enregistré.</li>';
  return [`<h1>Après un rapport non protégé</h1>${DISC}<form id="af" class="card"><label>Date du rapport<input type="date" name="day" required max="${today()}" value="${today()}"></label><label>Contraception utilisée<select name="contra">${Object.entries(CONTRA).map(([k, t]) => `<option value="${k}">${t}</option>`).join('')}</select></label><label>Incident<select name="inc">${Object.entries(INC).map(([k, t]) => `<option value="${k}">${t}</option>`).join('')}</select></label><label class="chk"><input type="checkbox" name="save"> Enregistrer dans mon compte</label><button class="btn">Voir les informations</button><p class="msg" role="status"></p></form><div id="aout" aria-live="polite"></div><h2>Mes rapports enregistrés</h2><ul>${reps}</ul>`,
    () => {
      bind('#af', async (f, set) => {
        if (f.save) { await api('/journal', 'POST', { kind: 'rapport', day: f.day, data: { contra: f.contra, inc: f.inc } }); await refresh(); }
        $('#aout').innerHTML = advice(f);
      });
      document.querySelectorAll('[data-jdel]').forEach(b => b.onclick = async () => { await api('/journal/' + b.dataset.jdel, 'DELETE'); await refresh(); route(); });
    }];
};

V.parametres = () => [`<h1>Paramètres</h1><section class="card"><h2>Rappels</h2><form id="rmf"><label class="chk"><input type="checkbox" name="reminders"${S.profile.reminders ? ' checked' : ''}> Afficher un rappel discret sur le tableau de bord à l’approche des règles estimées</label><button class="btn">Enregistrer</button><p class="msg" role="status"></p></form></section>
<section class="card"><h2>Session</h2><p>Connectée : ${esc(S.user)}</p><button class="btn alt" id="lo">Se déconnecter</button></section>
<section class="card"><h2>Supprimer mon compte et mes données</h2><p>Cette action est immédiate et définitive.</p><form id="df"><label>Mot de passe<input type="password" name="password" required autocomplete="current-password"></label><button class="btn del">Supprimer définitivement</button><p class="msg" role="status"></p></form></section>`,
  () => {
    bind('#rmf', async (f, set) => { const p = S.profile; await api('/profile', 'PUT', { period_len: p.period_len, cycle_len: p.cycle_len, cycle_var: p.cycle_var, reminders: !!f.reminders }); await refresh(); set('Enregistré.', true); });
    $('#lo').onclick = async () => { await api('/logout', 'POST'); S.user = null; location.hash = '#/'; route(); };
    bind('#df', async f => { if (!confirm('Supprimer définitivement votre compte et toutes vos données ?')) return; await api('/account/delete', 'POST', { password: f.password }); Object.assign(S, { user: null, cycles: [], profile: {}, journal: [] }); location.hash = '#/'; route(); });
  }];

async function route() {
  const [page, qs] = location.hash.replace(/^#\/?/, '').split('?');
  if (PRIVSET.has(page) && !S.user) { location.hash = '#/connexion'; return; }
  if (S.user && (page === 'connexion' || page === 'inscription')) { location.hash = '#/tableau'; return; }
  const L = S.user ? [...PUB, ...PRIV] : [...PUB, ['connexion', 'Connexion'], ['inscription', 'Inscription']];
  $('#nav').innerHTML = L.map(([k, t]) => `<a href="#/${k}"${k === page ? ' aria-current="page"' : ''}>${t}</a>`).join('');
  const r = (V[page] || (() => '<h1>Page introuvable</h1><p><a href="#/">Retour à l’accueil</a></p>'))(new URLSearchParams(qs || ''));
  const [html, init] = Array.isArray(r) ? r : [r];
  const app = $('#app'); app.innerHTML = html; if (init) init();
  document.title = (app.querySelector('h1')?.textContent || 'Mon Cycle') + ' – Mon Cycle';
}
async function start() { try { S.user = (await api('/me')).email; await refresh(); } catch (e) { S.user = null; } }
window.addEventListener('hashchange', () => { route(); $('#app').focus(); });
start().then(route);
})();
