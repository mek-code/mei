/* Règles de calcul (RM-01 à RM-06). Aucune dépendance au DOM : testable avec Node.
   Toutes les sorties sont des ESTIMATIONS ; aucun jour n'est jamais déclaré « sans risque ». */
(function (root) {
  const DAY = 864e5, T = s => Date.parse(s + 'T00:00:00Z'), I = t => new Date(t).toISOString().slice(0, 10);
  const add = (s, n) => I(T(s) + n * DAY), diff = (a, b) => Math.round((T(a) - T(b)) / DAY);
  const LUTEAL = 14; // durée lutéale moyenne supposée : valeur indicative, à faire valider

  function analyze(cycles, profile, today) {
    profile = profile || {};
    const pl = profile.period_len || null;
    const real = cycles.filter(c => !c.traces), traces = cycles.filter(c => c.traces);
    const recorded = d => {
      for (const c of real) if (d >= c.start && d <= (c.end || add(c.start, (pl || 1) - 1))) return 'period';
      for (const c of traces) if (d === c.start) return 'traces';
      return null;
    };
    const base = { level: 'none', n: 0, sufficient: false, late: 0, state: d => recorded(d) || 'none' };
    const starts = [...new Set(real.map(c => c.start))].sort();
    if (!starts.length) return { ...base, reason: 'no-data' };

    const lens = [];
    for (let i = 1; i < starts.length; i++) { const l = diff(starts[i], starts[i - 1]); if (l >= 15 && l <= 90) lens.push(l); }
    const rec = lens.slice(-6), n = rec.length; // RM-04 : recalcul sur l'historique récent
    const avg = n ? Math.round(rec.reduce((a, b) => a + b, 0) / n) : (profile.cycle_len || null); // RM-02 : pas de 28 j par défaut
    const range = n >= 2 ? Math.max(...rec) - Math.min(...rec) : (profile.cycle_var ?? null);
    const lastStart = starts[starts.length - 1];
    if (!avg) return { ...base, reason: 'no-length', lastStart, n };

    let level = 'high'; // RM-05 : incertitude explicite
    if (n >= 3 && range !== null && range <= 4) level = 'low';
    else if (n >= 2 && range <= 7) level = 'moderate';
    else if (n < 2 && range !== null && range <= 3) level = 'moderate';
    const sufficient = level !== 'high';
    const pad = Math.ceil((range || 0) / 2);
    const proj = [0, 1, 2, 3, 4].map(k => add(lastStart, k * avg));
    const wins = [0, 1, 2].map(k => { const o = add(proj[k + 1], -LUTEAL); return { ovu: o, from: add(o, -5 - pad), to: add(o, 1 + pad) }; });
    const end = proj[3];

    const state = d => {
      const r = recorded(d); if (r) return r;
      if (d < lastStart || d > end) return 'none';
      for (let k = 1; k <= 3; k++) if (d >= add(proj[k], -pad) && d <= add(proj[k], (pl || 1) - 1 + pad)) return 'next';
      if (!sufficient) return 'uncertain';
      for (const w of wins) { if (d === w.ovu) return 'ovu'; if (d >= w.from && d <= w.to) return 'fertile'; }
      return 'lower';
    };
    return { level, n, avg, range, pad, lastStart, nextStart: proj[1], late: Math.max(0, diff(today, proj[1])), wins, sufficient, state };
  }
  const api = { analyze, add, diff };
  if (typeof module !== 'undefined') module.exports = api; else root.Calc = api;
})(this);
