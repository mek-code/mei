const assert = require('assert'), { analyze, add } = require('../public/calc.js');
const mk = s => s.map((start, i) => ({ id: i, start, end: null, traces: 0 }));
let a = analyze(mk(['2026-01-01', '2026-01-29', '2026-02-26', '2026-03-26']), {}, '2026-04-01');
assert.equal(a.avg, 28); assert.equal(a.level, 'low'); assert.equal(a.nextStart, '2026-04-23');
assert.equal(a.wins[0].ovu, '2026-04-09'); assert.equal(a.state('2026-04-09'), 'ovu');
assert.equal(analyze([], {}, '2026-04-01').level, 'none');                       // pas de cycle supposé
assert.equal(analyze(mk(['2026-01-01']), {}, '2026-01-05').reason, 'no-length');  // pas de 28 j par défaut
a = analyze(mk(['2026-01-01', '2026-01-20', '2026-03-01', '2026-03-25']), {}, '2026-04-01');
assert.equal(a.level, 'high'); assert.ok(!['fertile', 'ovu', 'lower'].includes(a.state('2026-03-30'))); // jamais de « faible risque » si incertain
a = analyze(mk(['2026-01-01']), { cycle_len: 30, cycle_var: 2 }, '2026-01-10');
assert.equal(a.nextStart, '2026-01-31'); assert.equal(add('2026-02-28', 1), '2026-03-01');
console.log('calc: OK');
