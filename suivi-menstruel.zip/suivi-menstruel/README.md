# Mon Cycle — site de suivi menstruel (v1)

Site responsive en français : comptes, profil menstruel, calendrier avec estimations et incertitude,
historique, journal, outil « après un rapport », rappels discrets, suppression du compte.
Aucune dépendance à installer : Python 3.9+ uniquement (serveur + SQLite).

## Lancer en local
    COOKIE_SECURE=0 python3 server.py      # http://localhost:8000
    node tests/calc.test.js                 # tests des règles de calcul (Node, facultatif)

## Déployer (production)
Le site a un back-end : il faut un hébergement capable d'exécuter Python (VPS, Render, Railway,
Fly.io, PythonAnywhere...). Un hébergement mutualisé purement statique ne suffit pas.
1. Copier le dossier sur le serveur, définir les variables de `.env.example`
   (BASE_URL en https, TRUST_PROXY=1 derrière un proxy, SMTP_* pour les e-mails).
2. `python3 server.py` (ou `docker build -t moncycle . && docker run -p 8000:8000 -v $PWD/data:/app/data moncycle`).
3. Mettre un proxy HTTPS devant (voir `Caddyfile`). **HTTPS est obligatoire** (cookies Secure).
4. Sauvegarder régulièrement `data/app.db` (chiffrer les sauvegardes, accès restreint).
Sur une plateforme à disque éphémère, ajouter un volume persistant pour `data/`.

## Structure
- `server.py` : API + sécurité (scrypt, sessions HttpOnly, SameSite=Strict, contrôle d'accès par compte, limitation de tentatives, CSP stricte, aucun journal d'accès)
- `public/calc.js` : règles de calcul séparées de l'interface (RM-01 à RM-06), testées dans `tests/`
- `public/app.js`, `index.html`, `style.css` : interface (clavier, ARIA, symboles en plus des couleurs)

## À faire avant la mise en ligne
- Faire valider par un professionnel de santé reproductive : règles de calcul (lutéale 14 j, seuils d'incertitude dans `calc.js`), textes de prévention et délais de contraception d'urgence, adaptés aux pays ciblés.
- Compléter la politique de confidentialité (responsable du traitement, durée de conservation, base légale) avec un juriste.
- Renseigner le SMTP, sinon le lien de réinitialisation s'affiche seulement dans les logs du serveur.
- Hors v1 : notifications push, export des données, maquettes et guide utilisateur (livrables du CDC non inclus).
