#!/usr/bin/env python3
"""Mon Cycle - serveur sans dépendance externe (Python 3.9+, SQLite)."""
import hashlib, hmac, json, mimetypes, os, re, secrets, smtplib, sqlite3, sys, time, traceback
from datetime import date, timedelta
from email.message import EmailMessage
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

ROOT = os.path.dirname(os.path.abspath(__file__))
PUB = os.path.join(ROOT, "public")
DB = os.environ.get("DB_PATH", os.path.join(ROOT, "data", "app.db"))
SECURE = os.environ.get("COOKIE_SECURE", "1") == "1"      # 0 uniquement pour tester en http local
BASE_URL = os.environ.get("BASE_URL", "http://localhost:8000")
TRUST_PROXY = os.environ.get("TRUST_PROXY", "0") == "1"
SESSION_SECONDS = 14 * 86400
HITS = {}

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, pw TEXT NOT NULL, created TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(h TEXT PRIMARY KEY, uid INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, exp REAL NOT NULL);
CREATE TABLE IF NOT EXISTS resets(h TEXT PRIMARY KEY, uid INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, exp REAL NOT NULL);
CREATE TABLE IF NOT EXISTS profile(uid INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, period_len INTEGER, cycle_len INTEGER, cycle_var INTEGER, reminders INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS cycles(id INTEGER PRIMARY KEY, uid INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, start TEXT NOT NULL, end TEXT, traces INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS journal(id INTEGER PRIMARY KEY, uid INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, kind TEXT NOT NULL, day TEXT NOT NULL, data TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS i_cycles ON cycles(uid); CREATE INDEX IF NOT EXISTS i_journal ON journal(uid);
"""

SEC = [
    ("Content-Security-Policy", "default-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"),
    ("X-Content-Type-Options", "nosniff"), ("Referrer-Policy", "no-referrer"), ("X-Frame-Options", "DENY"),
] + ([("Strict-Transport-Security", "max-age=31536000")] if SECURE else [])


class Err(Exception):
    def __init__(self, code, msg):
        self.code, self.msg = code, msg


def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c


sha = lambda s: hashlib.sha256(s.encode()).hexdigest()
_kdf = lambda p, salt: hashlib.scrypt(p.encode(), salt=salt, n=2 ** 14, r=8, p=1, dklen=32)


def hash_pw(p):
    salt = os.urandom(16)
    return salt.hex() + ":" + _kdf(p, salt).hex()


def check_pw(p, stored):
    s, h = stored.split(":")
    return hmac.compare_digest(_kdf(p, bytes.fromhex(s)).hex(), h)


def day(v):
    if not isinstance(v, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", v):
        raise ValueError
    d = date.fromisoformat(v)
    if d < date(2000, 1, 1) or d > date.today() + timedelta(days=1):
        raise ValueError
    return v


def num(v, lo, hi):
    if v in (None, ""):
        return None
    v = int(v)
    if not lo <= v <= hi:
        raise ValueError
    return v


def limited(ip):
    now = time.time()
    l = [t for t in HITS.get(ip, []) if now - t < 300] + [now]
    HITS[ip] = l
    return len(l) > 15


def mail(to, subject, text):
    host = os.environ.get("SMTP_HOST")
    if not host:
        print(f"[DEV] e-mail non configuré (SMTP_HOST). Message pour {to} : {text}", file=sys.stderr)
        return
    m = EmailMessage()
    m["From"], m["To"], m["Subject"] = os.environ.get("SMTP_FROM", "no-reply@localhost"), to, subject
    m.set_content(text)
    with smtplib.SMTP(host, int(os.environ.get("SMTP_PORT", "587"))) as s:
        s.starttls()
        if os.environ.get("SMTP_USER"):
            s.login(os.environ["SMTP_USER"], os.environ.get("SMTP_PASS", ""))
        s.send_message(m)


def cookie(tok, age):
    return ("Set-Cookie", f"sid={tok}; Path=/; HttpOnly; SameSite=Strict; Max-Age={age}" + ("; Secure" if SECURE else ""))


def new_session(c, uid):
    tok = secrets.token_urlsafe(32)
    c.execute("DELETE FROM sessions WHERE exp<?", (time.time(),))
    c.execute("INSERT INTO sessions VALUES(?,?,?)", (sha(tok), uid, time.time() + SESSION_SECONDS))
    return [cookie(tok, SESSION_SECONDS)]


def password(d):
    p = d.get("password")
    if not isinstance(p, str) or len(p) < 10 or len(p) > 200:
        raise Err(400, "Le mot de passe doit contenir au moins 10 caractères.")
    return p


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    log_message = lambda self, *a: None   # pas de journal d'accès : collecte minimale

    def _send(self, code, body, ctype, extra=()):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in list(SEC) + list(extra):
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, code, obj, extra=()):
        self._send(code, json.dumps(obj).encode(), "application/json; charset=utf-8", [("Cache-Control", "no-store")] + list(extra))

    def do_GET(self): self.dispatch("GET")
    def do_POST(self): self.dispatch("POST")
    def do_PUT(self): self.dispatch("PUT")
    def do_DELETE(self): self.dispatch("DELETE")

    def static(self, p):
        p = "/index.html" if p == "/" else p
        f = os.path.normpath(os.path.join(PUB, p.lstrip("/")))
        if not f.startswith(PUB + os.sep) or not os.path.isfile(f):
            return self._json(404, {"error": "Introuvable"})
        ct = mimetypes.guess_type(f)[0] or "application/octet-stream"
        with open(f, "rb") as fh:
            self._send(200, fh.read(), ct + ("; charset=utf-8" if ct.startswith("text/") or ct.endswith("javascript") else ""),
                       [("Cache-Control", "no-cache")])

    def dispatch(self, m):
        n = int(self.headers.get("Content-Length") or 0)
        if n > 20000:
            self.close_connection = True
            return self._json(413, {"error": "Requête trop volumineuse"})
        raw = self.rfile.read(n) if n else b""
        p = urlparse(self.path).path
        if not p.startswith("/api/"):
            return self.static(p) if m == "GET" else self._json(405, {"error": "Méthode non autorisée"})
        try:
            if m != "GET":
                o = self.headers.get("Origin")
                if o and urlparse(o).netloc != self.headers.get("Host"):
                    raise Err(403, "Origine refusée")
                if raw and "application/json" not in (self.headers.get("Content-Type") or ""):
                    raise Err(415, "JSON requis")
            d = json.loads(raw) if raw else {}
            if not isinstance(d, dict):
                raise Err(400, "Corps invalide")
            c = db()
            try:
                code, obj, extra = self.route(c, m, p, d)
                c.commit()
            finally:
                c.close()
            self._json(code, obj, extra)
        except Err as e:
            self._json(e.code, {"error": e.msg})
        except (ValueError, KeyError, TypeError):
            self._json(400, {"error": "Données invalides"})
        except Exception:
            traceback.print_exc()
            self._json(500, {"error": "Erreur serveur"})

    def ip(self):
        if TRUST_PROXY:
            return (self.headers.get("X-Forwarded-For") or "").split(",")[0].strip() or self.client_address[0]
        return self.client_address[0]

    def uid(self, c):
        ck = SimpleCookie(self.headers.get("Cookie") or "")
        if "sid" not in ck:
            raise Err(401, "Non connecté")
        r = c.execute("SELECT uid FROM sessions WHERE h=? AND exp>?", (sha(ck["sid"].value), time.time())).fetchone()
        if not r:
            raise Err(401, "Session expirée")
        return r["uid"]

    def route(self, c, m, p, d):
        if m == "POST" and p in ("/api/register", "/api/login", "/api/reset-request", "/api/reset") and limited(self.ip()):
            raise Err(429, "Trop de tentatives. Réessayez dans quelques minutes.")
        if m == "POST" and p == "/api/register":
            email = str(d.get("email", "")).strip().lower()
            if not re.fullmatch(r"[^@\s]{1,64}@[^@\s]{1,255}\.[^@\s]{2,}", email):
                raise Err(400, "Adresse e-mail invalide.")
            if d.get("consent") is not True:
                raise Err(400, "Vous devez accepter les conditions d’utilisation et la politique de confidentialité.")
            pw = password(d)
            if c.execute("SELECT 1 FROM users WHERE email=?", (email,)).fetchone():
                raise Err(409, "Un compte existe déjà avec cette adresse.")
            uid = c.execute("INSERT INTO users(email,pw,created) VALUES(?,?,?)", (email, hash_pw(pw), date.today().isoformat())).lastrowid
            return 201, {"email": email}, new_session(c, uid)
        if m == "POST" and p == "/api/login":
            email = str(d.get("email", "")).strip().lower()
            r = c.execute("SELECT id,pw FROM users WHERE email=?", (email,)).fetchone()
            ok = check_pw(str(d.get("password", "")), r["pw"]) if r else (check_pw("x", hash_pw("y")) and False)
            if not ok:
                raise Err(401, "E-mail ou mot de passe incorrect.")
            return 200, {"email": email}, new_session(c, r["id"])
        if m == "POST" and p == "/api/reset-request":
            email = str(d.get("email", "")).strip().lower()
            r = c.execute("SELECT id FROM users WHERE email=?", (email,)).fetchone()
            if r:
                tok = secrets.token_urlsafe(32)
                c.execute("INSERT INTO resets VALUES(?,?,?)", (sha(tok), r["id"], time.time() + 3600))
                mail(email, "Réinitialisation de votre mot de passe",
                     f"Pour choisir un nouveau mot de passe (lien valable 1 h) : {BASE_URL}/#/reinitialiser?token={tok}")
            return 200, {"ok": True}, []
        if m == "POST" and p == "/api/reset":
            r = c.execute("SELECT uid FROM resets WHERE h=? AND exp>?", (sha(str(d.get("token", ""))), time.time())).fetchone()
            if not r:
                raise Err(400, "Lien invalide ou expiré.")
            c.execute("UPDATE users SET pw=? WHERE id=?", (hash_pw(password(d)), r["uid"]))
            c.execute("DELETE FROM resets WHERE uid=?", (r["uid"],))
            c.execute("DELETE FROM sessions WHERE uid=?", (r["uid"],))
            return 200, {"ok": True}, []

        uid = self.uid(c)
        if m == "GET" and p == "/api/me":
            return 200, {"email": c.execute("SELECT email FROM users WHERE id=?", (uid,)).fetchone()["email"]}, []
        if m == "POST" and p == "/api/logout":
            ck = SimpleCookie(self.headers.get("Cookie") or "")
            c.execute("DELETE FROM sessions WHERE h=?", (sha(ck["sid"].value),))
            return 200, {"ok": True}, [cookie("", 0)]
        if m == "POST" and p == "/api/account/delete":
            r = c.execute("SELECT pw FROM users WHERE id=?", (uid,)).fetchone()
            if not check_pw(str(d.get("password", "")), r["pw"]):
                raise Err(403, "Mot de passe incorrect.")
            c.execute("DELETE FROM users WHERE id=?", (uid,))
            return 200, {"ok": True}, [cookie("", 0)]

        if p == "/api/profile":
            if m == "GET":
                r = c.execute("SELECT period_len,cycle_len,cycle_var,reminders FROM profile WHERE uid=?", (uid,)).fetchone()
                return 200, {"profile": dict(r) if r else {}}, []
            if m == "PUT":
                v = (num(d.get("period_len"), 1, 15), num(d.get("cycle_len"), 15, 90), num(d.get("cycle_var"), 0, 30), 1 if d.get("reminders") else 0)
                c.execute("INSERT OR REPLACE INTO profile VALUES(?,?,?,?,?)", (uid,) + v)
                return 200, {"ok": True}, []

        if p == "/api/cycles" and m == "GET":
            rows = c.execute("SELECT id,start,end,traces FROM cycles WHERE uid=? ORDER BY start", (uid,)).fetchall()
            return 200, {"cycles": [dict(r) for r in rows]}, []
        if p == "/api/cycles" and m == "POST":
            s, e = day(d.get("start")), (day(d["end"]) if d.get("end") else None)
            if e and not s <= e <= (date.fromisoformat(s) + timedelta(days=20)).isoformat():
                raise Err(400, "La date de fin doit suivre la date de début (20 jours maximum).")
            if c.execute("SELECT COUNT(*) n FROM cycles WHERE uid=?", (uid,)).fetchone()["n"] > 1000:
                raise Err(400, "Limite atteinte.")
            i = c.execute("INSERT INTO cycles(uid,start,end,traces) VALUES(?,?,?,?)", (uid, s, e, 1 if d.get("traces") else 0)).lastrowid
            return 201, {"id": i}, []
        mc = re.fullmatch(r"/api/cycles/(\d+)", p)
        if mc and m == "PUT":
            s, e = day(d.get("start")), (day(d["end"]) if d.get("end") else None)
            if e and not s <= e <= (date.fromisoformat(s) + timedelta(days=20)).isoformat():
                raise Err(400, "La date de fin doit suivre la date de début (20 jours maximum).")
            c.execute("UPDATE cycles SET start=?,end=?,traces=? WHERE id=? AND uid=?", (s, e, 1 if d.get("traces") else 0, mc.group(1), uid))
            return 200, {"ok": True}, []
        if mc and m == "DELETE":
            c.execute("DELETE FROM cycles WHERE id=? AND uid=?", (mc.group(1), uid))
            return 200, {"ok": True}, []

        if p == "/api/journal" and m == "GET":
            rows = c.execute("SELECT id,kind,day,data FROM journal WHERE uid=? ORDER BY day DESC,id DESC", (uid,)).fetchall()
            return 200, {"journal": [{**dict(r), "data": json.loads(r["data"])} for r in rows]}, []
        if p == "/api/journal" and m == "POST":
            kind = d.get("kind")
            data = d.get("data")
            if kind not in ("note", "rapport") or not isinstance(data, dict):
                raise ValueError
            txt = json.dumps(data, ensure_ascii=False)
            if len(txt) > 2000:
                raise ValueError
            if c.execute("SELECT COUNT(*) n FROM journal WHERE uid=?", (uid,)).fetchone()["n"] > 5000:
                raise Err(400, "Limite atteinte.")
            i = c.execute("INSERT INTO journal(uid,kind,day,data) VALUES(?,?,?,?)", (uid, kind, day(d.get("day")), txt)).lastrowid
            return 201, {"id": i}, []
        mj = re.fullmatch(r"/api/journal/(\d+)", p)
        if mj and m == "DELETE":
            c.execute("DELETE FROM journal WHERE id=? AND uid=?", (mj.group(1), uid))
            return 200, {"ok": True}, []
        raise Err(404, "Introuvable")


def main():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    c = db()
    c.executescript(SCHEMA)
    c.close()
    host, port = os.environ.get("HOST", "0.0.0.0"), int(os.environ.get("PORT", "8000"))
    print(f"Mon Cycle : http://{host}:{port}", file=sys.stderr)
    ThreadingHTTPServer((host, port), Handler).serve_forever()


if __name__ == "__main__":
    main()
